from django.shortcuts import render
from django.http import JsonResponse
from django.http import FileResponse
from django.core.files.base import ContentFile
from .models import BPEModel, Corpus
import json
import re
from django.core.files.base import ContentFile

def home(request):
    bpe_models = BPEModel.objects.all()
    return render(request, 'main/home.html', {'bpe_models': bpe_models})

def tokenize_text(request):
    if request.method == 'POST':
        tokenizer_id = request.POST.get('tokenizer')
        text = request.POST.get('text', '')
        file = request.FILES.get('file')

        if not tokenizer_id:
            return JsonResponse({'success': False, 'error': 'Please select a tokenizer.'})

        try:
            tokenizer = BPEModel.objects.get(id=tokenizer_id)
        except BPEModel.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Invalid tokenizer selected.'})

        if file:
            text = file.read().decode('utf-8')

        if not text:
            return JsonResponse({'success': False, 'error': 'No text provided for tokenization.'})

        # Use the tokenizer's vocabulary to tokenize the text
        vocabulary = json.loads(tokenizer.vocabulary)
        tokens = tokenize_with_vocab(text, vocabulary)

        return JsonResponse({
            'success': True,
            'tokenized_text': ' '.join(tokens),
            'token_count': len(tokens),
            'char_count': len(text)
        })

    return JsonResponse({'success': False, 'error': 'Invalid request method.'})

def train_tokenizer(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        vocab_size = request.POST.get('vocab_size')
        corpus_file = request.FILES.get('corpus_file')
        save_tokenizer = request.POST.get('save_tokenizer') == 'true'

        if not all([name, vocab_size, corpus_file]):
            return JsonResponse({'success': False, 'error': 'Missing required fields.'})

        try:
            # Read corpus file
            corpus_text = corpus_file.read().decode('utf-8')

            # Build vocabulary
            words = re.findall(r'\b\w+\b', corpus_text.lower())
            word_freq = {}
            for word in words:
                if word in word_freq:
                    word_freq[word] += 1
                else:
                    word_freq[word] = 1

            # Sort by frequency and limit to vocab_size
            vocab = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:int(vocab_size)]
            vocab = [word for word, _ in vocab]

            # Create the new tokenizer model
            new_tokenizer = BPEModel(
                name=name,
                vocab_size=int(vocab_size),
                vocabulary=json.dumps(vocab)
            )

            # Save the corpus file
            corpus = Corpus.objects.create(
                name=f"Corpus for {name}",
                file=corpus_file
            )

            # Save the tokenizer if requested
            if save_tokenizer:
                new_tokenizer.save()
                message = "Tokenizer trained and saved successfully."
            else:
                message = "Tokenizer trained successfully but not saved."

            return JsonResponse({
                'success': True,
                'tokenizer_id': new_tokenizer.id if save_tokenizer else None,
                'tokenizer_name': new_tokenizer.name,
                'message': message
            })
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Invalid request method.'})

def process_file(request):
    if request.method == 'POST':
        file = request.FILES.get('file')
        tokenizer_id = request.POST.get('tokenizer')
        
        if not file or not tokenizer_id:
            return JsonResponse({'success': False, 'error': 'Missing file or tokenizer.'})
        
        try:
            tokenizer = BPEModel.objects.get(id=tokenizer_id)
            file_content = file.read().decode('utf-8')
            
            # Tokenize the file content
            vocabulary = json.loads(tokenizer.vocabulary)
            tokens = tokenize_with_vocab(file_content, vocabulary)
            
            # Create a new file with tokenized content
            tokenized_file = ContentFile(' '.join(tokens))
            tokenized_file.name = f"tokenized_{file.name}"
            
            return JsonResponse({
                'success': True,
                'token_count': len(tokens),
                'char_count': len(file_content),
                'tokenized_file_url': tokenized_file.name  # You might want to save this file and return its URL
            })
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method.'})

def tokenize_file(request):
    if request.method == 'POST':
        file = request.FILES.get('file')
        tokenizer_id = request.POST.get('tokenizer')
        
        if not file or not tokenizer_id:
            return JsonResponse({'success': False, 'error': 'Missing file or tokenizer.'})
        
        try:
            tokenizer = BPEModel.objects.get(id=tokenizer_id)
            file_content = file.read().decode('utf-8')
            
            # Tokenize the file content
            vocabulary = json.loads(tokenizer.vocabulary)
            tokens = tokenize_with_vocab(file_content, vocabulary)
            
            # Create a new file with tokenized content
            tokenized_content = ' '.join(tokens)
            tokenized_file = ContentFile(tokenized_content)
            tokenized_file.name = f"tokenized_{file.name}"
            
            # Prepare the response
            response = FileResponse(tokenized_file, content_type='text/plain')
            response['Content-Disposition'] = f'attachment; filename="{tokenized_file.name}"'
            
            return response
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'success': False, 'error': 'Invalid request method.'})

def tokenize_with_vocab(text, vocabulary):
    # Simple tokenization using the vocabulary
    tokens = []
    for word in re.findall(r'\b\w+\b', text.lower()):
        if word in vocabulary:
            tokens.append(word)
        else:
            tokens.extend(list(word))  # If not in vocab, split into characters
    return tokens