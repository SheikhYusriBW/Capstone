from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('tokenize/', views.tokenize_text, name='tokenize_text'),
    path('train/', views.train_tokenizer, name='train_tokenizer'),
    path('process_file/', views.process_file, name='process_file'),
    path('tokenize-file/', views.tokenize_file, name='tokenize_file'),
]