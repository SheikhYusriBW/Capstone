from django import forms
from .models import Corpus, BPEModel

class TextInputForm(forms.Form):
    text = forms.CharField(widget=forms.Textarea(attrs={'maxlength': '500'}))
    file = forms.FileField(required=False)
    tokenizer = forms.ModelChoiceField(queryset=BPEModel.objects.all())

class CorpusUploadForm(forms.ModelForm):
    class Meta:
        model = Corpus
        fields = ['name', 'file']

class TokenizerForm(forms.Form):
    name = forms.CharField(max_length=100)
    vocab_size = forms.IntegerField(min_value=1000, max_value=100000)
    corpus = forms.ModelChoiceField(queryset=Corpus.objects.all())