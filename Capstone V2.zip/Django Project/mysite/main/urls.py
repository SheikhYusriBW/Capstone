from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("upload_corpus/", views.upload_corpus, name="upload_corpus"),
    path("train_tokenizer/", views.train_tokenizer, name="train_tokenizer"),
    path("tokenize_text/", views.tokenize_text, name="tokenize_text"),
    path("process_file/", views.process_file, name="process_file"),
]