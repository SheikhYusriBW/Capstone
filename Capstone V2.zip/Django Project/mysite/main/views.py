from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from .models import BPEModel, Corpus
from .forms import TextInputForm, CorpusUploadForm, TokenizerForm
import json

def home(request):
    bpe_models = BPEModel.objects.all()
    corpora = Corpus.objects.all()
    context = {
        'bpe_models': bpe_models,
        'corpora': corpora,
    }
    return render(request, 'main/home.html', context)

def upload_corpus(request):
    if request.method == 'POST':
        form = CorpusUploadForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return JsonResponse({'success': True, 'message': 'Corpus uploaded successfully'})
        else:
            return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=405)

def train_tokenizer(request):
    if request.method == 'POST':
        form = TokenizerForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            vocab_size = form.cleaned_data['vocab_size']
            corpus = form.cleaned_data['corpus']
            
            # Implement tokenizer training logic here
            # This is a placeholder, replace with actual training logic
            new_tokenizer = BPEModel.objects.create(
                name=name,
                vocab_size=vocab_size,
                # Add other necessary fields
            )
            
            return JsonResponse({'success': True, 'message': 'Tokenizer trained successfully'})
        else:
            return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=405)

def tokenize_text(request):
    if request.method == 'POST':
        text = request.POST.get('text', '')
        uploaded_file = request.FILES.get('file')
        tokenizer_id = request.POST.get('tokenizer')

        if uploaded_file:
            text = uploaded_file.read().decode('utf-8')
        
        if not text:
            return JsonResponse({'error': 'No text provided'}, status=400)

        if len(text) > 500:
            return JsonResponse({'error': 'Text exceeds 500 characters'}, status=400)

        try:
            tokenizer = BPEModel.objects.get(id=tokenizer_id)
        except BPEModel.DoesNotExist:
            return JsonResponse({'error': 'Invalid tokenizer selected'}, status=400)

        # Implement your tokenization logic here
        # This is a placeholder, replace with actual tokenization
        tokenized_text = text.split()  # Simple word splitting as placeholder

        return JsonResponse({
            'tokenized_text': tokenized_text,
            'token_count': len(tokenized_text),
            'char_count': len(text)
        })

    return JsonResponse({'error': 'Invalid request method'}, status=405)

def process_file(request):
    if request.method == 'POST':
        uploaded_file = request.FILES.get('file')
        tokenizer_id = request.POST.get('tokenizer')

        if not uploaded_file:
            return JsonResponse({'error': 'No file provided'}, status=400)

        try:
            tokenizer = BPEModel.objects.get(id=tokenizer_id)
        except BPEModel.DoesNotExist:
            return JsonResponse({'error': 'Invalid tokenizer selected'}, status=400)

        # Read and process the file
        file_content = uploaded_file.read().decode('utf-8')

        # Implement your file processing logic here
        # This is a placeholder, replace with actual processing
        processed_content = file_content.split()  # Simple word splitting as placeholder

        # Create a response with the processed content
        response = HttpResponse(json.dumps(processed_content), content_type='application/json')
        response['Content-Disposition'] = f'attachment; filename=processed_{uploaded_file.name}'

        return response

    return JsonResponse({'error': 'Invalid request method'}, status=405)