from django.db import models

# Create your models here.

class BPEModel(models.Model):
    name = models.CharField(max_length=100)
    vocab_size = models.IntegerField()
    model_file = models.FileField(upload_to='bpe_models/')
    created_at = models.DateTimeField(auto_now_add=True)

class Corpus(models.Model):
    name = models.CharField(max_length=100)
    file = models.FileField(upload_to='corpora/')
    created_at = models.DateTimeField(auto_now_add=True)